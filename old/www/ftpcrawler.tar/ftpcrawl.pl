#!/usr/bin/perl
use Net::FTP;
use DBI;
use locale;

$dbh = DBI->connect("DBI:mysql:remedyftp:ftplist.mine.nu","root","relisys");
$lvl = 0;


($ip,$port,$user,$pass,$ftp_id) = @ARGV;
$ftp = Net::FTP->new($ip, Port => $port, Timeout => 10, Debug => 0);
if(!$ftp) {
    mark_bad($ftp_id);
    die("couldn't connect to $ip:$port");
}
if(!$ftp->login($user,$pass)) {
    #dont mark bad, it might just be full or something
    #mark_bad($ftp_id);
    die("Couldn't login on $ip:$port using $user/$pass");
}

#@list = $ftp->dir();
#foreach (@list) {
#    do_dir($ftp,$ftp->dir());
#}
do_dir($ftp,$ftp->dir());
sub mark_bad {
    ($ftp_id) = @_;
    $ftp_id or die("No ftp id supplied to mark_bad()");
#    $dbh->do("UPDATE ftp_hosts SET active='N' WHERE ftp_id=$ftp_id");
    $dbh->do("UPDATE ftp SET online='1' WHERE id=$ftp_id");
}

#$file:
# 0: perm
# 1: links (files in directory)
# 2: owner
# 3: group owner
# 4: size
# 5: mod month
# 6: mod day
# 7: mod time
# 8: filename

sub do_dir {
    my ($ftp,@dir) = @_;
    my $pwd = $ftp->pwd();
    my $ent = ();
    foreach my $file (@dir) {
#                0        1      2      3       4     5      6      7                 8
#	$file =~ /(.{10}) +(\d*) +(\S+) +(\S+) +(\d+) +(\S+) +(\d+) +(\d{1,2}:\d{1,2}) (.*)$/;
	$file =~ /(.{10}).+\d{1,2}:\d{1,2} (.*$)/m;
	$ent[0] = $1;
	$ent[8] = $2;
	#$fileold = $file;
	#$file[0] = $1;
	#$file[8] = $9;
#	@file = split(/ +/,$file);
#	$file[8] = join(" ", @file[8..$#file]);
	#print $fileold."\n";
	#print $file[0]."\n";

	if($ent[0] =~ /^d/ or
	   ($lvl == 1 and $ent[0] =~ /^l/)) {
	    $lvl++;
	    $ftp->cwd($ent[8]) or die("cwd failed! Something is wrong!");
	    do_dir($ftp,$ftp->dir());
	    $ftp->cdup();
	    $lvl--;
	} elsif($ent[8] =~ /(?:avi|mpg|mpeg|mp3|jpg|gif|png|asf|mov|\d{3}|rar|r\d{2}|gz|bin|iso|zip|nfo)$/i) {
	    print $ent[8]."\n";
	    $SQL = "INSERT INTO ftp_files SET ftp_id='$ftp_id',path=".$dbh->quote($pwd).",file=".$dbh->quote($ent[8]);
	    if(length($pwd) > 255) {
		warn("too long pathname, use a BLOB instead! yuck!");
	    }
	    $dbh->do($SQL);
	}
	$ent = undef;
    }

}
