#!/usr/bin/perl

#$file:
# 0: perm
# 1: links (files in directory)
# 2: owner
# 3: group owner
# 4: size
# 5: mod month
# 6: mod day
# 7: mod time
# 8: filename

use DBI;

$dbh = DBI->connect("DBI:mysql:remedyftp:ftplist.mine.nu","root","relisys");

$sth = $dbh->prepare("SELECT id as ftp_id,ip, uname as user,pass,port FROM ftp");

$sth->execute();
@ftps      = ();

while($hash_ref = $sth->fetchrow_hashref) {
    #print "Added ftp://".$hash_ref->{user}.":".$hash_ref->{port}."@".$hash_ref->{ip}.":".$hash_ref->{port}."/\n";
    push(@ftps,$hash_ref);
}
print @ftps." FTPS\n";
$dbh->do("DELETE FROM ftp_files");

for(1...55) {
    spawn_child(shift(@ftps));
}


warn("startade dom f�rsta 10 barnen");
while(wait()) {
    my $ftp = shift @ftps;
    if ($ftp) {
	spawn_child($ftp);
    }
}
die("nu e de slut");
#do_fork($hash_ref->{ip}, $hash_ref->{port}, $hash_ref->{user}, $hash_ref->{pass}, $hash_ref->{ftp_id});
#exec "perl", "ftptest.pl", 

sub spawn_child {
    $hash_ref = shift;

    print "ftp://".$hash_ref->{user}.":".$hash_ref->{port}."@".$hash_ref->{ip}.":".$hash_ref->{port}."/\n";

    unless(fork) {
	exec "ftpcrawl.pl", $hash_ref->{ip}, $hash_ref->{port}, $hash_ref->{user}, $hash_ref->{pass}, $hash_ref->{ftp_id};
    }
}


