<?PHP
require_once("lib/ftpsearch.php");
?>
<PRE>
<?PHP foreach(db_list_files() as $file): ?>
ftp://<?=$file["ip"]?><?=$file["path"]?>/<?=$file["file"]?>

<?PHP endforeach; ?>
</PRE>
