<?PHP
require_once("lib/ftpsearch.php");
include("header.php");
?>

Det finns <B><?= db_num_files(); ?></B> filer i databasen.

<form action="ftpsearch.php">

<table border="1"><tr>
<td>Filnamn</td><td><INPUT TYPE="text" NAME="file" width="50%" value="<?=$file?>"></td>
</tr><tr><td colspan="2"><i>S�kning sker i den ordning du skrivit in nyckelord.<br>
S� om du skrivit in "tomb raider" s� kommer den att matcha *tomb*raider* allts� alla filer(&kataloger om du valt det) som ineh�ller tomb och sedan raider.</i></td></tr><tr>
</tr><tr>
<td colspan="2"><INPUT TYPE="checkbox" NAME="searchdirs"> Inkludera katalognamn i s�kning
</tr><tr>
<td>Filtyp</td><td><INPUT TYPE="text" NAME="suffix"></td>
</tr><tr><td colspan="2"><i>tex: mp3, avi, mpg m.m.</i></td></tr><tr>
</tr><tr>
<td colspan="2"><input type="submit" VALUE="Skicka s�kning"></td></tr>
</table>

</form>


<?PHP
foreach($HTTP_GET_VARS as $key => $val) {
  if(empty($val)) unset($HTTP_GET_VARS[$key]);
}
if(count($HTTP_GET_VARS) > 0) {
  $and = FALSE;
  $SQL="SELECT ftp_files.*,ftp_hosts.*\n"
    ."FROM ftp_files\n"
    ."LEFT JOIN ftp_hosts ON ftp_files.ftp_id=ftp_hosts.ftp_id\n"
    ."WHERE\n";

  if(!empty($file)) {
    $and=TRUE;
    $file = addslashes(str_replace(" ","%",$file));
    $SQL .= "(file LIKE '%$file%'";
    if(isset($searchdirs)) {
      $SQL .= " OR path LIKE '%$file%'";
    }
    $SQL .= ")\n";
  }

  if(!empty($suffix)) {
    if($and) $SQL .= "AND ";
    $and = TRUE;
    $suffix = addslashes($suffix);
    $SQL .= "file LIKE '%.$suffix'";
  }
#  my_var_dump($SQL);
  $rows = db_get_rows(&$SQL);
?>
<P>Hittade <?=count($rows)?> tr�ffar.</P>
<pre>
<?PHP
foreach($rows as $file):
?>
<A HREF="ftp://<?=$file["user"]?>:<?=$file["pass"]?>@<?=$file["ip"]?><?=$file["path"]?>/<?=$file["file"]?>">ftp://<?=$file["user"]?>:<?=$file["pass"]?>@<?=$file["ip"]?><?=$file["path"]?>/<?=$file["file"]?></A>
<?PHP
endforeach;
?>
   </pre>

<?PHP
}
include("footer.php");
?>
