<HTML>
<HEAD>
<TITLE>Remedy FTP-Search by mog</TITLE>
</HEAD>
<BODY>
<H1 ALIGN="center">Remedy FTP-Search</H1>
Tips: s�k p� <A HREF="ftpsearch.php?suffix=avi">avi</A> som filsuffix om 
du vill 
ha film, <A HREF="ftpsearch.php?suffix=mp3">mp3</A> om du vill ha 
musik och s�.
<P>
