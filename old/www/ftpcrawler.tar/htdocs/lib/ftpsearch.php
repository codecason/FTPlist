<?PHP

function my_var_dump($var) {
  print "<PRE>";var_dump($var);print "</PRE>";
}

function db_connect() {
  static $link=FALSE;
  if($link) { return $link; }
  $link = mysql_pconnect("localhost","root","");
  mysql_select_db("ftpsearch");
  return $link;
}

function db_get_ftps() {
  $SQL = "SELECT * FROM ftp_hosts";
  return db_get_rows_by_field(&$SQL,"ftp_id");
}

function db_get_rows_by_field($SQL,$field) {
  $rows = array();
  $result = db_query(&$SQL);
  while($row = mysql_fetch_assoc($result)) {
    $rows[$field] = $row;
  }
  return $rows;
}

function db_get_rows($SQL) {
  $rows = array();
  $result = db_query(&$SQL);
  while($row = mysql_fetch_assoc($result)) {
    $rows[] = $row;
  }
  return $rows;
}

function db_query($SQL) {
  db_connect();
  $result = mysql_query(&$SQL);
  if(!$result) trigger_error("Error in SQL query '$SQL':<br>".mysql_error(),E_USER_ERROR);
  return $result;
}

function db_list_files() {
  db_connect();
  $SQL="SELECT ftp_files.*,ftp_hosts.*\n"
    ."FROM ftp_files\n"
    ."LEFT JOIN ftp_hosts ON ftp_files.ftp_id=ftp_hosts.ftp_id";
  return db_get_rows(&$SQL);
}

function db_num_files() {
  db_connect();
  $SQL="SELECT COUNT(*) FROM ftp_files";
  return current(db_get_row(&$SQL));
}

function db_get_row($SQL) {
  db_connect();
  $result = db_query(&$SQL);
  $return = mysql_fetch_assoc($result);
  mysql_free_result($result);
  return $return;
}
?>
